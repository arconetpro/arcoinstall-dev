.. _help.discord:

Discord
=======

There's a discord channel which is frequented by some `contributors <https://github.com/archlinux/archinstall/graphs/contributors>`_.

To join the server, head over to `https://discord.gg/aDeMffrxNg <https://discord.gg/aDeMffrxNg>`_ and join in.
There's not many rules other than common sense and to treat others with respect. The general chat is for off-topic things as well.

There's the ``@Party Animals`` role if you want notifications of new releases which is posted in the ``#Release Party`` channel.
Another thing is the ``@Contributors`` role can be activated by contributors by writing ``!verify`` and follow the verification process.

Hop in, we hope to see you there! : )
