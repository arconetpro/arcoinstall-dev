from enum import StrEnum, auto


class Repo(StrEnum):
	MULTILIB = auto()
	TESTING = auto()
