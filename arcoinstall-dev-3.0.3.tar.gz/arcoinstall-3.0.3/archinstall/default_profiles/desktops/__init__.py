from enum import Enum


class SeatAccess(Enum):
	seatd = 'seatd'
	polkit = 'polkit'
